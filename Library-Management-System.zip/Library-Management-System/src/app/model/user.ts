export class User {

    id: number;
    lname:string;
    fname:string;
    email:string;
    password:string;
    value:string;
  role: string;
  username:string;
  loginAs: string;
}